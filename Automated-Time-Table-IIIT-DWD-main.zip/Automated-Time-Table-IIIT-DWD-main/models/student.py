
STUDENTS_DATA = [
    {
        "id": "24BCS073",
        "name": "Mayur Raju",
        "section": "A",
        "courses": ["MA261", "CS262_A", "CS263_A", "CS264_A", "HSS_A", "ESD"]
    },
    {
        "id": "24BCS062",
        "name": "Lakshya Singh",
        "section": "A",
        "courses": ["MA261", "CS262_A", "CS263_A", "CS264_A", "HSS_A"]
    },
    {
        "id": "24BCS087",
        "name": "Nikunj Srivastav",
        "section": "B",
        "courses": ["MA261", "CS262_B", "CS263_B", "CS264_B", "HSS_B"]
    },
    {
        "id": "24BCS085",
        "name": "Nihal Singh",
        "section": "B",
        "courses": ["MA261", "CS262_B", "CS263_B", "CS264_B", "HSS_B", "ESD"]
    }
]
