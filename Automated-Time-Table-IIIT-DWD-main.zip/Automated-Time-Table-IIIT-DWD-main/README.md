# Automated Timetable Scheduling System

This project automates the generation of class and exam timetables for IIIT Dharwad.

## Features
- Student & Faculty Management
- Automated Class & Exam Scheduling
- Conflict Detection & Auto-Resolution
- Room Allocation
- Export (CSV, PDF)
## Team Members (Software Sages)
- Nikunj Srivastav (24BCS087)
- Sudhanshu Baberwal (24BCS147)
- Thejas Gowda U M (24BCS157)
- Shaik Moiz (24BCS133)
